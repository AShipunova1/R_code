get_username <-
function(){
    return(as.character(Sys.info()["user"]))
}
